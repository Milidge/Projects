package com.example.notagame

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.credits.*
import kotlinx.android.synthetic.main.instructions.*

class Credits : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.credits)
        back4.setOnClickListener{
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}