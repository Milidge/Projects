package com.example.notagame

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.ImageView
import android.widget.TableRow
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.excel.*
import kotlinx.coroutines.*
import android.media.MediaPlayer
import android.widget.EditText
import kotlinx.android.synthetic.main.settings.*


class Excel : AppCompatActivity () {
    override fun onBackPressed() {
        song1!!.stop()
        startActivity(Intent(this, MainActivity::class.java))
    }
    companion object {
        var maincount = 0
        var score = 0
        var level = 1
        var musicOn = true
        var song1: MediaPlayer? = null
        var songGameOver: MediaPlayer? = null
    }
    @SuppressLint("SetTextI18n")
    @RequiresApi(Build.VERSION_CODES.M)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.excel)
        song1 = MediaPlayer.create(this, R.raw.song1)
        songGameOver = MediaPlayer.create(this, R.raw.song5)

        val hspreference = SavedData(this)
        highscore1.text = "High: " + hspreference.gethighscore().toString()

        var carb1 = 0
        var carb2 = 3
        var carb3 = 2
        var carb4 = 5
        var carb5 = 3

        var caro1 = 1
        var caro2 = 4
        var caro3 = 6
        var caro4 = 2
        var caro5 = 6
        var caro6 = 0
        var caro7 = 4

        var logr1 = 2
        var logr2 = 5
        var logr3 = 0
        var logr4 = 2
        var logr5 = 4

        var logl1 = 1
        var logl2 = 4
        var logl3 = 6
        var logl4 = 0
        var logl5 = 2
        var logl6 = 5

        var pad1 = 1
        var pad2 = 3
        var pad3 = 5

        var playing = false
        var delayTime2 = 2000L
        var ipos = 13
        var jpos = 3
        var alive = true
        var dead = false
        var iter1 = true
        var iter2 = 0
        var count = 0
        score = 0
        level = 1

        back10.setOnClickListener {
            if(playing){
                Excel.song1!!.stop()
            }
            startActivity(Intent(this, Selection::class.java))
        }
        for (i in 0 until 15) {
            for (j in 0 until 7) { //loops through all boxes
                val row = table.getChildAt(i) as TableRow
                val box = row.getChildAt(j) as ImageView
                box.alpha = 0f
                val rowt = sheet.getChildAt(i) as TableRow
                val boxt = rowt.getChildAt(j) as EditText
                boxt.alpha = 1f
                boxt.isEnabled = true
                up.isEnabled = false
                down.isEnabled = false
                left.isEnabled = false
                right.isEnabled = false
            }
        }
        play.setOnClickListener {
            if (playing) { //if button is clicked while playing
                song1!!.pause()
                play.setImageResource(R.drawable.play)
                playing = false
                for (i in 0 until 15) {
                    for (j in 0 until 7) { //loops through all boxes
                        val row = table.getChildAt(i) as TableRow
                        val box = row.getChildAt(j) as ImageView
                        val rowt = sheet.getChildAt(i) as TableRow
                        val boxt = rowt.getChildAt(j) as EditText
                        boxt.alpha = 1f
                        boxt.isEnabled = true
                        box.alpha = 0f
                        up.isEnabled = false
                        down.isEnabled = false
                        left.isEnabled = false
                        right.isEnabled = false
                    }
                }

            }else if(!playing) { //if user is not playing and button is clicked
                if(musicOn) {
                    song1!!.start()
                    song1!!.isLooping = true
                }
                playing = true
                play.setImageResource(R.drawable.pause)
                for (i in 0 until 15) {
                    for (j in 0 until 7) { //loops through all boxes
                        val row = table.getChildAt(i) as TableRow
                        val box = row.getChildAt(j) as ImageView //every box to-do
                        box.isEnabled = false
                        box.alpha = 1f
                        val rowt = sheet.getChildAt(i) as TableRow
                        val boxt = rowt.getChildAt(j) as EditText
                        boxt.alpha = 0f
                        boxt.isEnabled = false
                        up.isEnabled = true
                        down.isEnabled = true
                        left.isEnabled = true
                        right.isEnabled = true
                    }
                }
                if(count == 0) {
                    count = 1
                    GlobalScope.launch(Dispatchers.Main) {
                        while (alive) { //collision detector
                            delay(delayTime2)
                            var row1 = table.getChildAt(2) as TableRow
                            if (carb1 == 0) {
                                val box1 = row1.getChildAt(carb1) as ImageView
                                box1.foreground = null
                                carb1 = -1
                            } else if (carb1 == -1) {
                                val newBox = row1.getChildAt(6) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.carb)
                                newBox.foreground = image
                                carb1 = 6

                            } else {
                                val box1 = row1.getChildAt(carb1) as ImageView
                                box1.foreground = null
                                val newBox = row1.getChildAt(carb1 - 1) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.carb)
                                newBox.foreground = image
                                carb1 -= 1
                            }

                            var row2 = table.getChildAt(2) as TableRow
                            if (carb2 == 0) {
                                val box2 = row2.getChildAt(carb2) as ImageView
                                box2.foreground = null
                                carb2 = -1
                            } else if (carb2 == -1) {
                                val newBox = row2.getChildAt(6) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.carb)
                                newBox.foreground = image
                                carb2 = 6
                            } else {
                                val box2 = row2.getChildAt(carb2) as ImageView
                                box2.foreground = null
                                val newBox = row2.getChildAt(carb2 - 1) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.carb)
                                newBox.foreground = image
                                carb2 -= 1
                            }

                            var row3 = table.getChildAt(8) as TableRow
                            if (carb3 == 0) {
                                val box3 = row3.getChildAt(carb3) as ImageView
                                box3.foreground = null
                                carb3 = -1
                            } else if (carb3 == -1) {
                                val newBox = row3.getChildAt(6) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.carb)
                                newBox.foreground = image
                                carb3 = 6
                            } else {
                                val box3 = row3.getChildAt(carb3) as ImageView
                                box3.foreground = null
                                val newBox = row3.getChildAt(carb3 - 1) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.carb)
                                newBox.foreground = image
                                carb3 -= 1
                            }

                            var row4 = table.getChildAt(8) as TableRow
                            if (carb4 == 0) {
                                val box4 = row4.getChildAt(carb4) as ImageView
                                box4.foreground = null
                                carb4 = -1
                            } else if (carb4 == -1) {
                                val newBox = row4.getChildAt(6) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.carb)
                                newBox.foreground = image
                                carb4 = 6
                            } else {
                                val box4 = row4.getChildAt(carb4) as ImageView
                                box4.foreground = null
                                val newBox = row4.getChildAt(carb4 - 1) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.carb)
                                newBox.foreground = image
                                carb4 -= 1
                            }

                            var row5 = table.getChildAt(11) as TableRow
                            if (carb5 == 0) {
                                val box5 = row5.getChildAt(carb5) as ImageView
                                box5.foreground = null
                                carb5 = -1
                            } else if (carb5 == -1) {
                                val newBox = row5.getChildAt(6) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.carb)
                                newBox.foreground = image
                                carb5 = 6
                            } else {
                                val box5 = row5.getChildAt(carb5) as ImageView
                                box5.foreground = null
                                val newBox = row5.getChildAt(carb5 - 1) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.carb)
                                newBox.foreground = image
                                carb5 -= 1
                            }

                            var row6 = table.getChildAt(1) as TableRow
                            if (caro1 == 6) {
                                val box6 = row6.getChildAt(caro1) as ImageView
                                box6.foreground = null
                                caro1 = -1
                            } else if (caro1 == -1) {
                                val newBox = row6.getChildAt(0) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.caro)
                                newBox.foreground = image
                                caro1 = 0
                            } else {
                                val box6 = row6.getChildAt(caro1) as ImageView
                                box6.foreground = null
                                val newBox = row6.getChildAt(caro1 + 1) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.caro)
                                newBox.foreground = image
                                caro1 += 1
                            }

                            var row7 = table.getChildAt(1) as TableRow
                            if (caro2 == 6) {
                                val box7 = row7.getChildAt(caro2) as ImageView
                                box7.foreground = null
                                caro2 = -1
                            } else if (caro2 == -1) {
                                val newBox = row7.getChildAt(0) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.caro)
                                newBox.foreground = image
                                caro2 = 0
                            } else {
                                val box7 = row7.getChildAt(caro2) as ImageView
                                box7.foreground = null
                                val newBox = row7.getChildAt(caro2 + 1) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.caro)
                                newBox.foreground = image
                                caro2 += 1
                            }

                            var row8 = table.getChildAt(1) as TableRow
                            if (caro3 == 6) {
                                val box8 = row8.getChildAt(caro3) as ImageView
                                box8.foreground = null
                                caro3 = -1
                            } else if (caro3 == -1) {
                                val newBox = row8.getChildAt(0) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.caro)
                                newBox.foreground = image
                                caro3 = 0
                            } else {
                                val box8 = row8.getChildAt(caro3) as ImageView
                                box8.foreground = null
                                val newBox = row8.getChildAt(caro3 + 1) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.caro)
                                newBox.foreground = image
                                caro3 += 1
                            }

                            var row9 = table.getChildAt(9) as TableRow
                            if (caro4 == 6) {
                                val box9 = row9.getChildAt(caro4) as ImageView
                                box9.foreground = null
                                caro4 = -1
                            } else if (caro4 == -1) {
                                val newBox = row9.getChildAt(0) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.caro)
                                newBox.foreground = image
                                caro4 = 0
                            } else {
                                val box9 = row9.getChildAt(caro4) as ImageView
                                box9.foreground = null
                                val newBox = row9.getChildAt(caro4 + 1) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.caro)
                                newBox.foreground = image
                                caro4 += 1
                            }

                            var rowa = table.getChildAt(9) as TableRow
                            if (caro5 == 6) {
                                val boxa = rowa.getChildAt(caro5) as ImageView
                                boxa.foreground = null
                                caro5 = -1
                            } else if (caro5 == -1) {
                                val newBox = rowa.getChildAt(0) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.caro)
                                newBox.foreground = image
                                caro5 = 0
                            } else {
                                val boxa = rowa.getChildAt(caro5) as ImageView
                                boxa.foreground = null
                                val newBox = rowa.getChildAt(caro5 + 1) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.caro)
                                newBox.foreground = image
                                caro5 += 1
                            }

                            var rowb = table.getChildAt(12) as TableRow
                            if (caro6 == 6) {
                                val boxb = rowb.getChildAt(caro6) as ImageView
                                boxb.foreground = null
                                caro6 = -1
                            } else if (caro6 == -1) {
                                val newBox = rowb.getChildAt(0) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.caro)
                                newBox.foreground = image
                                caro6 = 0
                            } else {
                                val boxb = rowb.getChildAt(caro6) as ImageView
                                boxb.foreground = null
                                val newBox = rowb.getChildAt(caro6 + 1) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.caro)
                                newBox.foreground = image
                                caro6 += 1
                            }

                            var rowc = table.getChildAt(12) as TableRow
                            if (caro7 == 6) {
                                val boxc = rowc.getChildAt(caro7) as ImageView
                                boxc.foreground = null
                                caro7 = -1
                            } else if (caro7 == -1) {
                                val newBox = rowc.getChildAt(0) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.caro)
                                newBox.foreground = image
                                caro7 = 0
                            } else {
                                val boxc = rowc.getChildAt(caro7) as ImageView
                                boxc.foreground = null
                                val newBox = rowc.getChildAt(caro7 + 1) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.caro)
                                newBox.foreground = image
                                caro7 += 1
                            }
                            if (iter1) {
                                var rowd = table.getChildAt(3) as TableRow
                                if (logr1 == 6) {
                                    val boxd = rowd.getChildAt(logr1) as ImageView
                                    boxd.foreground = null
                                    logr1 = -1
                                    if (ipos == 3 && jpos == logr1) {
                                        alive = false
                                    }
                                } else if (logr1 == -1) {
                                    val newBox = rowd.getChildAt(0) as ImageView
                                    val image =
                                        ContextCompat.getDrawable(newBox.context, R.drawable.log)
                                    newBox.foreground = image
                                    logr1 = 0
                                } else {
                                    val boxd = rowd.getChildAt(logr1) as ImageView
                                    boxd.foreground = null
                                    val newBox = rowd.getChildAt(logr1 + 1) as ImageView
                                    if (ipos == 3 && jpos == logr1) {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.froglog
                                            )
                                        newBox.foreground = image
                                        jpos += 1
                                    } else {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.log
                                            )
                                        newBox.foreground = image
                                    }
                                    logr1 += 1
                                }

                                var row11 = table.getChildAt(3) as TableRow
                                if (logr2 == 6) {
                                    val box11 = row11.getChildAt(logr2) as ImageView
                                    box11.foreground = null
                                    logr2 = -1
                                    if (ipos == 3 && jpos == logr2) {
                                        alive = false
                                    }
                                } else if (logr2 == -1) {
                                    val newBox = row11.getChildAt(0) as ImageView
                                    val image =
                                        ContextCompat.getDrawable(newBox.context, R.drawable.log)
                                    newBox.foreground = image
                                    logr2 = 0
                                } else {
                                    val box11 = row11.getChildAt(logr2) as ImageView
                                    box11.foreground = null
                                    val newBox = row11.getChildAt(logr2 + 1) as ImageView
                                    if (ipos == 3 && jpos == logr2) {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.froglog
                                            )
                                        newBox.foreground = image
                                        jpos += 1
                                    } else {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.log
                                            )
                                        newBox.foreground = image
                                    }
                                    logr2 += 1
                                }

                                var row13 = table.getChildAt(7) as TableRow
                                if (logr4 == 6) {
                                    val box13 = row13.getChildAt(logr4) as ImageView
                                    box13.foreground = null
                                    logr4 = -1
                                    if (ipos == 7 && jpos == logr4) {
                                        alive = false
                                    }
                                } else if (logr4 == -1) {
                                    val newBox = row13.getChildAt(0) as ImageView
                                    val image =
                                        ContextCompat.getDrawable(newBox.context, R.drawable.log)
                                    newBox.foreground = image
                                    logr4 = 0
                                } else {
                                    val box13 = row13.getChildAt(logr4) as ImageView
                                    box13.foreground = null
                                    val newBox = row13.getChildAt(logr4 + 1) as ImageView
                                    if (ipos == 7 && jpos == logr4) {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.froglog
                                            )
                                        newBox.foreground = image
                                        jpos += 1
                                    } else {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.log
                                            )
                                        newBox.foreground = image
                                    }
                                    logr4 += 1
                                }

                                var row12 = table.getChildAt(7) as TableRow
                                if (logr3 == 6) {
                                    val box12 = row12.getChildAt(logr3) as ImageView
                                    box12.foreground = null
                                    logr3 = -1
                                    if (ipos == 7 && jpos == logr3) {
                                        alive = false
                                    }
                                } else if (logr3 == -1) {
                                    val newBox = row12.getChildAt(0) as ImageView
                                    val image =
                                        ContextCompat.getDrawable(newBox.context, R.drawable.log)
                                    newBox.foreground = image
                                    logr3 = 0
                                } else {
                                    val box12 = row12.getChildAt(logr3) as ImageView
                                    box12.foreground = null
                                    val newBox = row12.getChildAt(logr3 + 1) as ImageView
                                    if (ipos == 7 && jpos == logr3) {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.froglog
                                            )
                                        newBox.foreground = image
                                        jpos += 1
                                    } else {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.log
                                            )
                                        newBox.foreground = image
                                    }
                                    logr3 += 1

                                }

                                var row14 = table.getChildAt(7) as TableRow
                                if (logr5 == 6) {
                                    val box14 = row14.getChildAt(logr5) as ImageView
                                    box14.foreground = null
                                    logr5 = -1
                                    if (ipos == 7 && jpos == logr5) {
                                        alive = false
                                    }
                                } else if (logr5 == -1) {
                                    val newBox = row14.getChildAt(0) as ImageView
                                    val image =
                                        ContextCompat.getDrawable(newBox.context, R.drawable.log)
                                    newBox.foreground = image
                                    logr5 = 0
                                } else {
                                    val box14 = row14.getChildAt(logr5) as ImageView
                                    box14.foreground = null
                                    val newBox = row14.getChildAt(logr5 + 1) as ImageView
                                    if (ipos == 7 && jpos == logr5) {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.froglog
                                            )
                                        newBox.foreground = image
                                        jpos += 1
                                    } else {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.log
                                            )
                                        newBox.foreground = image
                                    }
                                    logr5 += 1
                                }
                                iter1 = false
                            } else {
                                iter1 = true
                            }
                            if (iter2 == 0) {

                                var row20 = table.getChildAt(4) as TableRow
                                if (logl1 == 0) {
                                    val box20 = row20.getChildAt(logl1) as ImageView
                                    box20.foreground = null
                                    logl1 = -1
                                    if (ipos == 4 && jpos == logl1) {
                                        alive = false
                                    }
                                } else if (logl1 == -1) {
                                    val newBox = row20.getChildAt(6) as ImageView
                                    val image =
                                        ContextCompat.getDrawable(newBox.context, R.drawable.log)
                                    newBox.foreground = image
                                    logl1 = 6
                                } else {
                                    val box20 = row20.getChildAt(logl1) as ImageView
                                    box20.foreground = null
                                    val newBox = row20.getChildAt(logl1 - 1) as ImageView
                                    if (ipos == 4 && jpos == logl1) {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.froglog
                                            )
                                        newBox.foreground = image
                                        jpos -= 1
                                    } else {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.log
                                            )
                                        newBox.foreground = image
                                    }
                                    logl1 -= 1
                                }

                                var row21 = table.getChildAt(4) as TableRow
                                if (logl2 == 0) {
                                    val box21 = row21.getChildAt(logl2) as ImageView
                                    box21.foreground = null
                                    logl2 = -1
                                    if (ipos == 4 && jpos == logl2) {
                                        alive = false
                                    }
                                } else if (logl2 == -1) {
                                    val newBox = row21.getChildAt(6) as ImageView
                                    val image =
                                        ContextCompat.getDrawable(newBox.context, R.drawable.log)
                                    newBox.foreground = image
                                    logl2 = 6
                                } else {
                                    val box21 = row21.getChildAt(logl2) as ImageView
                                    box21.foreground = null
                                    val newBox = row21.getChildAt(logl2 - 1) as ImageView
                                    if (ipos == 4 && jpos == logl2) {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.froglog
                                            )
                                        newBox.foreground = image
                                        jpos -= 1
                                    } else {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.log
                                            )
                                        newBox.foreground = image
                                    }
                                    logl2 -= 1
                                }

                                var row22 = table.getChildAt(4) as TableRow
                                if (logl3 == 0) {
                                    val box22 = row22.getChildAt(logl3) as ImageView
                                    box22.foreground = null
                                    logl3 = -1
                                    if (ipos == 4 && jpos == logl3) {
                                        alive = false
                                    }
                                } else if (logl3 == -1) {
                                    val newBox = row22.getChildAt(6) as ImageView
                                    val image =
                                        ContextCompat.getDrawable(newBox.context, R.drawable.log)
                                    newBox.foreground = image
                                    logl3 = 6
                                } else {
                                    val box22 = row22.getChildAt(logl3) as ImageView
                                    box22.foreground = null
                                    val newBox = row22.getChildAt(logl3 - 1) as ImageView
                                    if (ipos == 4 && jpos == logl3) {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.froglog
                                            )
                                        newBox.foreground = image
                                        jpos -= 1
                                    } else {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.log
                                            )
                                        newBox.foreground = image
                                    }
                                    logl3 -= 1
                                }

                                var row23 = table.getChildAt(6) as TableRow
                                if (logl5 == 0) {
                                    val box23 = row23.getChildAt(logl5) as ImageView
                                    box23.foreground = null
                                    logl5 = -1
                                    if (ipos == 6 && jpos == logl5) {
                                        alive = false
                                    }
                                } else if (logl5 == -1) {
                                    val newBox = row23.getChildAt(6) as ImageView
                                    val image =
                                        ContextCompat.getDrawable(newBox.context, R.drawable.log)
                                    newBox.foreground = image
                                    logl5 = 6
                                } else {
                                    val box23 = row23.getChildAt(logl5) as ImageView
                                    box23.foreground = null
                                    val newBox = row23.getChildAt(logl5 - 1) as ImageView
                                    if (ipos == 6 && jpos == logl5) {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.froglog
                                            )
                                        newBox.foreground = image
                                        jpos -= 1
                                    } else {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.log
                                            )
                                        newBox.foreground = image
                                    }
                                    logl5 -= 1
                                }

                                var row25 = table.getChildAt(6) as TableRow
                                if (logl6 == 0) {
                                    val box25 = row25.getChildAt(logl6) as ImageView
                                    box25.foreground = null
                                    logl6 = -1
                                    if (ipos == 6 && jpos == logl6) {
                                        alive = false
                                    }
                                } else if (logl6 == -1) {
                                    val newBox = row25.getChildAt(6) as ImageView
                                    val image =
                                        ContextCompat.getDrawable(newBox.context, R.drawable.log)
                                    newBox.foreground = image
                                    logl6 = 6
                                } else {
                                    val box25 = row25.getChildAt(logl6) as ImageView
                                    box25.foreground = null
                                    val newBox = row25.getChildAt(logl6 - 1) as ImageView
                                    if (ipos == 6 && jpos == logl6) {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.froglog
                                            )
                                        newBox.foreground = image
                                        jpos -= 1
                                    } else {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.log
                                            )
                                        newBox.foreground = image
                                    }
                                    logl6 -= 1
                                }

                                var row26 = table.getChildAt(6) as TableRow
                                if (logl4 == 0) {
                                    val box26 = row26.getChildAt(logl4) as ImageView
                                    box26.foreground = null
                                    logl4 = -1
                                    if (ipos == 6 && jpos == logl4) {
                                        alive = false
                                    }
                                } else if (logl4 == -1) {
                                    val newBox = row26.getChildAt(6) as ImageView
                                    val image =
                                        ContextCompat.getDrawable(newBox.context, R.drawable.log)
                                    newBox.foreground = image
                                    logl4 = 6
                                } else {
                                    val box26 = row26.getChildAt(logl4) as ImageView
                                    box26.foreground = null
                                    val newBox = row26.getChildAt(logl4 - 1) as ImageView
                                    if (ipos == 6 && jpos == logl4) {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.froglog
                                            )
                                        newBox.foreground = image
                                        jpos -= 1
                                    } else {
                                        val image =
                                            ContextCompat.getDrawable(
                                                newBox.context,
                                                R.drawable.log
                                            )
                                        newBox.foreground = image
                                    }
                                    logl4 -= 1
                                }
                                iter2++

                            } else if (iter2 == 1) {
                                iter2++
                            } else if (iter2 == 2) {
                                iter2 = 0
                            }
                            //collision detector
                            if(alive && !dead) {
                                if (ipos == 2 && jpos == carb1 ||
                                    ipos == 2 && jpos == carb2 ||
                                    ipos == 8 && jpos == carb3 ||
                                    ipos == 8 && jpos == carb4 ||
                                    ipos == 11 && jpos == carb5 ||
                                    ipos == 1 && jpos == caro1 ||
                                    ipos == 1 && jpos == caro2 ||
                                    ipos == 1 && jpos == caro3 ||
                                    ipos == 9 && jpos == caro4 ||
                                    ipos == 9 && jpos == caro5 ||
                                    ipos == 12 && jpos == caro6 ||
                                    ipos == 12 && jpos == caro7 ||
                                    ipos == 3 && jpos != logr1 &&
                                    ipos == 3 && jpos != logr2 ||
                                    ipos == 7 && jpos != logr3 &&
                                    ipos == 7 && jpos != logr4 &&
                                    ipos == 7 && jpos != logr5 ||
                                    ipos == 4 && jpos != logl1 &&
                                    ipos == 4 && jpos != logl2 &&
                                    ipos == 4 && jpos != logl3 ||
                                    ipos == 6 && jpos != logl4 &&
                                    ipos == 6 && jpos != logl5 &&
                                    ipos == 6 && jpos != logl6 ||
                                    ipos == 5 && jpos != 1 &&
                                    ipos == 5 && jpos != 3 &&
                                    ipos == 5 && jpos != 5 && alive
                                ) {
                                    alive = false
                                    up.isEnabled = false
                                    down.isEnabled = false
                                    right.isEnabled = false
                                    left.isEnabled = false
                                    startActivity(Intent(this@Excel, Gameover::class.java))
                                }
                            }


                        }
                    }
                }

                up.setOnClickListener {
                    if (ipos == 3 && jpos == logr1) {
                        var rowlog = table.getChildAt(3) as TableRow
                        var boxlog = rowlog.getChildAt(logr1) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 3 && jpos == logr2) {
                        var rowlog = table.getChildAt(3) as TableRow
                        var boxlog = rowlog.getChildAt(logr2) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 7 && jpos == logr3) {
                        var rowlog = table.getChildAt(7) as TableRow
                        var boxlog = rowlog.getChildAt(logr3) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 7 && jpos == logr4) {
                        var rowlog = table.getChildAt(7) as TableRow
                        var boxlog = rowlog.getChildAt(logr4) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 7 && jpos == logr5) {
                        var rowlog = table.getChildAt(7) as TableRow
                        var boxlog = rowlog.getChildAt(logr5) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 4 && jpos == logl1) {
                        var rowlog = table.getChildAt(4) as TableRow
                        var boxlog = rowlog.getChildAt(logl1) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 4 && jpos == logl2) {
                        var rowlog = table.getChildAt(4) as TableRow
                        var boxlog = rowlog.getChildAt(logl2) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 4 && jpos == logl3) {
                        var rowlog = table.getChildAt(4) as TableRow
                        var boxlog = rowlog.getChildAt(logl3) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 6 && jpos == logl4) {
                        var rowlog = table.getChildAt(6) as TableRow
                        var boxlog = rowlog.getChildAt(logl4) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 6 && jpos == logl5) {
                        var rowlog = table.getChildAt(6) as TableRow
                        var boxlog = rowlog.getChildAt(logl5) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 6 && jpos == logl6) {
                        var rowlog = table.getChildAt(6) as TableRow
                        var boxlog = rowlog.getChildAt(logl6) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 5 && jpos == pad1) {
                        var rowlog = table.getChildAt(5) as TableRow
                        var boxlog = rowlog.getChildAt(pad1) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.pad)

                    }
                    if (ipos == 5 && jpos == pad2) {
                        var rowlog = table.getChildAt(5) as TableRow
                        var boxlog = rowlog.getChildAt(pad2) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.pad)

                    }
                    if (ipos == 5 && jpos == pad3) {
                        var rowlog = table.getChildAt(5) as TableRow
                        var boxlog = rowlog.getChildAt(pad3) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.pad)

                    }
                    if (ipos >= 1) {
                        for (i in 0 until 15) {
                            var row = table.getChildAt(i) as TableRow
                            for (j in 0 until 7) { //loops through all boxes

                                val box = row.getChildAt(j) as ImageView //every box to-do
                                if (i == ipos && j == jpos) { //box has frog
                                    val newRow = table.getChildAt(i - 1) as TableRow
                                    val newBox = newRow.getChildAt(j) as ImageView
                                    val image =
                                        ContextCompat.getDrawable(
                                            newBox.context,
                                            R.drawable.frog
                                        )
                                    newBox.foreground = image
                                    if (ipos != 3 && ipos != 4 && ipos != 5 && ipos != 6 && ipos != 7) {
                                        box.foreground = null
                                    }
                                    newRow.background = row.background
                                    ipos-- //make new ipos to be one higher

                                }
                            }
                        }
                        score += level
                    } else if (ipos == 0) {
                        val row = table.getChildAt(0) as TableRow
                        for (j in 0 until 7) { //loops through all boxes
                            val box = row.getChildAt(j) as ImageView //every box to-do
                            if (j == jpos) { //box has frog
                                val newRow = table.getChildAt(14) as TableRow
                                val newBox = newRow.getChildAt(j) as ImageView
                                val image =
                                    ContextCompat.getDrawable(newBox.context, R.drawable.frog)
                                newBox.foreground = image
                                box.foreground = null
                                newRow.background = row.background
                            }
                        }
                        ipos = 14
                        level += 1
                        score += level * 5
                        if (delayTime2 >= 1000) {
                            delayTime2 -= 200
                        }else if(delayTime2 in 400..1000){
                            delayTime2 -= 100
                        }

                    }
                    score1.text = score.toString()
                    level1.text = "Level: $level"
                    if (score >= hspreference.gethighscore()) {
                        hspreference.sethighscore(score)
                        highscore1.text = "High: " + hspreference.gethighscore().toString()
                    }
                    if (ipos == 3 && jpos == logr1) {
                        var rowlog = table.getChildAt(3) as TableRow
                        var boxlog = rowlog.getChildAt(logr1) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 3 && jpos == logr2) {
                        var rowlog = table.getChildAt(3) as TableRow
                        var boxlog = rowlog.getChildAt(logr2) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 7 && jpos == logr3) {
                        var rowlog = table.getChildAt(7) as TableRow
                        var boxlog = rowlog.getChildAt(logr3) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 7 && jpos == logr4) {
                        var rowlog = table.getChildAt(7) as TableRow
                        var boxlog = rowlog.getChildAt(logr4) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 7 && jpos == logr5) {
                        var rowlog = table.getChildAt(7) as TableRow
                        var boxlog = rowlog.getChildAt(logr5) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 4 && jpos == logl1) {
                        var rowlog = table.getChildAt(4) as TableRow
                        var boxlog = rowlog.getChildAt(logl1) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 4 && jpos == logl2) {
                        var rowlog = table.getChildAt(4) as TableRow
                        var boxlog = rowlog.getChildAt(logl2) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 4 && jpos == logl3) {
                        var rowlog = table.getChildAt(4) as TableRow
                        var boxlog = rowlog.getChildAt(logl3) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 6 && jpos == logl4) {
                        var rowlog = table.getChildAt(6) as TableRow
                        var boxlog = rowlog.getChildAt(logl4) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 6 && jpos == logl5) {
                        var rowlog = table.getChildAt(6) as TableRow
                        var boxlog = rowlog.getChildAt(logl5) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 6 && jpos == logl6) {
                        var rowlog = table.getChildAt(6) as TableRow
                        var boxlog = rowlog.getChildAt(logl6) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 5 && jpos == pad1) {
                        var rowlog = table.getChildAt(5) as TableRow
                        var boxlog = rowlog.getChildAt(pad1) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.frogpad)

                    }
                    if (ipos == 5 && jpos == pad2) {
                        var rowlog = table.getChildAt(5) as TableRow
                        var boxlog = rowlog.getChildAt(pad2) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.frogpad)

                    }
                    if (ipos == 5 && jpos == pad3) {
                        var rowlog = table.getChildAt(5) as TableRow
                        var boxlog = rowlog.getChildAt(pad3) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.frogpad)

                    }
                    if (ipos == 2 && jpos == carb1 ||
                        ipos == 2 && jpos == carb2 ||
                        ipos == 8 && jpos == carb3 ||
                        ipos == 8 && jpos == carb4 ||
                        ipos == 11 && jpos == carb5 ||
                        ipos == 1 && jpos == caro1 ||
                        ipos == 1 && jpos == caro2 ||
                        ipos == 1 && jpos == caro3 ||
                        ipos == 9 && jpos == caro4 ||
                        ipos == 9 && jpos == caro5 ||
                        ipos == 12 && jpos == caro6 ||
                        ipos == 12 && jpos == caro7 ||
                        ipos == 3 && jpos != logr1 &&
                        ipos == 3 && jpos != logr2 ||
                        ipos == 7 && jpos != logr3 &&
                        ipos == 7 && jpos != logr4 &&
                        ipos == 7 && jpos != logr5 ||
                        ipos == 4 && jpos != logl1 &&
                        ipos == 4 && jpos != logl2 &&
                        ipos == 4 && jpos != logl3 ||
                        ipos == 6 && jpos != logl4 &&
                        ipos == 6 && jpos != logl5 &&
                        ipos == 6 && jpos != logl6 ||
                        ipos == 5 && jpos != 1 &&
                        ipos == 5 && jpos != 3 &&
                        ipos == 5 && jpos != 5
                    ) {
                        dead = true
                        alive = false
                        delayTime2 = 10000
                        up.isEnabled = false
                        down.isEnabled = false
                        right.isEnabled = false
                        left.isEnabled = false
                        startActivity(Intent(this, Gameover::class.java))
                    }

                }

                down.setOnClickListener {
                    if (ipos == 3 && jpos == logr1) {
                        var rowlog = table.getChildAt(3) as TableRow
                        var boxlog = rowlog.getChildAt(logr1) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 3 && jpos == logr2) {
                        var rowlog = table.getChildAt(3) as TableRow
                        var boxlog = rowlog.getChildAt(logr2) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 7 && jpos == logr3) {
                        var rowlog = table.getChildAt(7) as TableRow
                        var boxlog = rowlog.getChildAt(logr3) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 7 && jpos == logr4) {
                        var rowlog = table.getChildAt(7) as TableRow
                        var boxlog = rowlog.getChildAt(logr4) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 7 && jpos == logr5) {
                        var rowlog = table.getChildAt(7) as TableRow
                        var boxlog = rowlog.getChildAt(logr5) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 4 && jpos == logl1) {
                        var rowlog = table.getChildAt(4) as TableRow
                        var boxlog = rowlog.getChildAt(logl1) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 4 && jpos == logl2) {
                        var rowlog = table.getChildAt(4) as TableRow
                        var boxlog = rowlog.getChildAt(logl2) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 4 && jpos == logl3) {
                        var rowlog = table.getChildAt(4) as TableRow
                        var boxlog = rowlog.getChildAt(logl3) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 6 && jpos == logl4) {
                        var rowlog = table.getChildAt(6) as TableRow
                        var boxlog = rowlog.getChildAt(logl4) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 6 && jpos == logl5) {
                        var rowlog = table.getChildAt(6) as TableRow
                        var boxlog = rowlog.getChildAt(logl5) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 6 && jpos == logl6) {
                        var rowlog = table.getChildAt(6) as TableRow
                        var boxlog = rowlog.getChildAt(logl6) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.log)

                    }
                    if (ipos == 5 && jpos == pad1) {
                        var rowlog = table.getChildAt(5) as TableRow
                        var boxlog = rowlog.getChildAt(pad1) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.pad)

                    }
                    if (ipos == 5 && jpos == pad2) {
                        var rowlog = table.getChildAt(5) as TableRow
                        var boxlog = rowlog.getChildAt(pad2) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.pad)

                    }
                    if (ipos == 5 && jpos == pad3) {
                        var rowlog = table.getChildAt(5) as TableRow
                        var boxlog = rowlog.getChildAt(pad3) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.pad)

                    }
                    //when swipe down
                    if (ipos <= 13) {
                        var changed = false
                        for (i in 0 until 15) {
                            val row = table.getChildAt(i) as TableRow
                            for (j in 0 until 7) { //loops through all boxes
                                val box = row.getChildAt(j) as ImageView //every box to-do
                                if (i == ipos && j == jpos && !changed) { //box has frog
                                    val newRow = table.getChildAt(i + 1) as TableRow
                                    val newBox = newRow.getChildAt(j) as ImageView
                                    val image =
                                        ContextCompat.getDrawable(
                                            newBox.context,
                                            R.drawable.frog
                                        )
                                    newBox.foreground = image
                                    if (ipos != 3 && ipos != 4 && ipos != 5 && ipos != 6 && ipos != 7) {
                                        box.foreground = null
                                    }
                                    newRow.background = row.background
                                    ipos++ //make new ipos to be one higher
                                    changed = true

                                }
                            }

                        }
                        if (score != 0) {
                            score -= level
                        }
                        score1.text = score.toString()
                    }
                    if (ipos == 3 && jpos == logr1) {
                        var rowlog = table.getChildAt(3) as TableRow
                        var boxlog = rowlog.getChildAt(logr1) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 3 && jpos == logr2) {
                        var rowlog = table.getChildAt(3) as TableRow
                        var boxlog = rowlog.getChildAt(logr2) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 7 && jpos == logr3) {
                        var rowlog = table.getChildAt(7) as TableRow
                        var boxlog = rowlog.getChildAt(logr3) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 7 && jpos == logr4) {
                        var rowlog = table.getChildAt(7) as TableRow
                        var boxlog = rowlog.getChildAt(logr4) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 7 && jpos == logr5) {
                        var rowlog = table.getChildAt(7) as TableRow
                        var boxlog = rowlog.getChildAt(logr5) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 4 && jpos == logl1) {
                        var rowlog = table.getChildAt(4) as TableRow
                        var boxlog = rowlog.getChildAt(logl1) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 4 && jpos == logl2) {
                        var rowlog = table.getChildAt(4) as TableRow
                        var boxlog = rowlog.getChildAt(logl2) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 4 && jpos == logl3) {
                        var rowlog = table.getChildAt(4) as TableRow
                        var boxlog = rowlog.getChildAt(logl3) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 6 && jpos == logl4) {
                        var rowlog = table.getChildAt(6) as TableRow
                        var boxlog = rowlog.getChildAt(logl4) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 6 && jpos == logl5) {
                        var rowlog = table.getChildAt(6) as TableRow
                        var boxlog = rowlog.getChildAt(logl5) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 6 && jpos == logl6) {
                        var rowlog = table.getChildAt(6) as TableRow
                        var boxlog = rowlog.getChildAt(logl6) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.froglog)

                    }
                    if (ipos == 5 && jpos == pad1) {
                        var rowlog = table.getChildAt(5) as TableRow
                        var boxlog = rowlog.getChildAt(pad1) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.frogpad)

                    }
                    if (ipos == 5 && jpos == pad2) {
                        var rowlog = table.getChildAt(5) as TableRow
                        var boxlog = rowlog.getChildAt(pad2) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.frogpad)

                    }
                    if (ipos == 5 && jpos == pad3) {
                        var rowlog = table.getChildAt(5) as TableRow
                        var boxlog = rowlog.getChildAt(pad3) as ImageView
                        boxlog.foreground =
                            ContextCompat.getDrawable(boxlog.context, R.drawable.frogpad)

                    }
                    if (ipos == 2 && jpos == carb1 ||
                        ipos == 2 && jpos == carb2 ||
                        ipos == 8 && jpos == carb3 ||
                        ipos == 8 && jpos == carb4 ||
                        ipos == 11 && jpos == carb5 ||
                        ipos == 1 && jpos == caro1 ||
                        ipos == 1 && jpos == caro2 ||
                        ipos == 1 && jpos == caro3 ||
                        ipos == 9 && jpos == caro4 ||
                        ipos == 9 && jpos == caro5 ||
                        ipos == 12 && jpos == caro6 ||
                        ipos == 12 && jpos == caro7 ||
                        ipos == 3 && jpos != logr1 &&
                        ipos == 3 && jpos != logr2 ||
                        ipos == 7 && jpos != logr3 &&
                        ipos == 7 && jpos != logr4 &&
                        ipos == 7 && jpos != logr5 ||
                        ipos == 4 && jpos != logl1 &&
                        ipos == 4 && jpos != logl2 &&
                        ipos == 4 && jpos != logl3 ||
                        ipos == 6 && jpos != logl4 &&
                        ipos == 6 && jpos != logl5 &&
                        ipos == 6 && jpos != logl6 ||
                        ipos == 5 && jpos != 1 &&
                        ipos == 5 && jpos != 3 &&
                        ipos == 5 && jpos != 5
                    ) {
                        dead = true
                        alive = false
                        delayTime2 = 10000
                        up.isEnabled = false
                        down.isEnabled = false
                        right.isEnabled = false
                        left.isEnabled = false
                        startActivity(Intent(this, Gameover::class.java))
                    }

                }

                left.setOnClickListener {
                    //when swipe left
                    if (jpos >= 1) {
                        for (i in 0 until 15) {
                            val row = table.getChildAt(i) as TableRow
                            for (j in 0 until 7) { //loops through all boxes

                                val box = row.getChildAt(j) as ImageView //every box to-do
                                if (i == ipos && j == jpos) { //box has frog
                                    val newRow = table.getChildAt(i) as TableRow
                                    val newBox = newRow.getChildAt(j - 1) as ImageView
                                    val image =
                                        ContextCompat.getDrawable(
                                            newBox.context,
                                            R.drawable.frog
                                        )
                                    newBox.foreground = image
                                    box.foreground = null
                                    newRow.background = row.background
                                    jpos-- //make new ipos to be one higher

                                }
                            }

                        }
                    }
                    if (ipos == 2 && jpos == carb1 ||
                        ipos == 2 && jpos == carb2 ||
                        ipos == 8 && jpos == carb3 ||
                        ipos == 8 && jpos == carb4 ||
                        ipos == 11 && jpos == carb5 ||
                        ipos == 1 && jpos == caro1 ||
                        ipos == 1 && jpos == caro2 ||
                        ipos == 1 && jpos == caro3 ||
                        ipos == 9 && jpos == caro4 ||
                        ipos == 9 && jpos == caro5 ||
                        ipos == 12 && jpos == caro6 ||
                        ipos == 12 && jpos == caro7 ||
                        ipos == 3 && jpos != logr1 &&
                        ipos == 3 && jpos != logr2 ||
                        ipos == 7 && jpos != logr3 &&
                        ipos == 7 && jpos != logr4 &&
                        ipos == 7 && jpos != logr5 ||
                        ipos == 4 && jpos != logl1 &&
                        ipos == 4 && jpos != logl2 &&
                        ipos == 4 && jpos != logl3 ||
                        ipos == 6 && jpos != logl4 &&
                        ipos == 6 && jpos != logl5 &&
                        ipos == 6 && jpos != logl6 ||
                        ipos == 5 && jpos != 1 &&
                        ipos == 5 && jpos != 3 &&
                        ipos == 5 && jpos != 5
                    ) {
                        alive = false
                        delayTime2 = 10000
                        up.isEnabled = false
                        down.isEnabled = false
                        right.isEnabled = false
                        left.isEnabled = false
                        dead = true
                        startActivity(Intent(this, Gameover::class.java))
                    }

                }

                right.setOnClickListener {
                    //when swipe right
                    if (jpos <= 5) {
                        var changed = false
                        for (i in 0 until 15) {
                            val row = table.getChildAt(i) as TableRow
                            for (j in 0 until 7) { //loops through all boxes
                                val box = row.getChildAt(j) as ImageView //every box to-do
                                if (i == ipos && j == jpos && !changed) { //box has frog
                                    val newRow = table.getChildAt(i) as TableRow
                                    val newBox = newRow.getChildAt(j + 1) as ImageView
                                    val image =
                                        ContextCompat.getDrawable(
                                            newBox.context,
                                            R.drawable.frog
                                        )
                                    newBox.foreground = image
                                    box.foreground = null
                                    newRow.background = row.background
                                    jpos++ //make new ipos to be one higher
                                    changed = true

                                }
                            }

                        }
                    }
                    if (ipos == 2 && jpos == carb1 ||
                        ipos == 2 && jpos == carb2 ||
                        ipos == 8 && jpos == carb3 ||
                        ipos == 8 && jpos == carb4 ||
                        ipos == 11 && jpos == carb5 ||
                        ipos == 1 && jpos == caro1 ||
                        ipos == 1 && jpos == caro2 ||
                        ipos == 1 && jpos == caro3 ||
                        ipos == 9 && jpos == caro4 ||
                        ipos == 9 && jpos == caro5 ||
                        ipos == 12 && jpos == caro6 ||
                        ipos == 12 && jpos == caro7 ||
                        ipos == 3 && jpos != logr1 &&
                        ipos == 3 && jpos != logr2 ||
                        ipos == 7 && jpos != logr3 &&
                        ipos == 7 && jpos != logr4 &&
                        ipos == 7 && jpos != logr5 ||
                        ipos == 4 && jpos != logl1 &&
                        ipos == 4 && jpos != logl2 &&
                        ipos == 4 && jpos != logl3 ||
                        ipos == 6 && jpos != logl4 &&
                        ipos == 6 && jpos != logl5 &&
                        ipos == 6 && jpos != logl6 ||
                        ipos == 5 && jpos != 1 &&
                        ipos == 5 && jpos != 3 &&
                        ipos == 5 && jpos != 5
                    ) {
                        alive = false
                        delayTime2 = 10000
                        up.isEnabled = false
                        down.isEnabled = false
                        right.isEnabled = false
                        left.isEnabled = false
                        dead = true
                        startActivity(Intent(this, Gameover::class.java))
                    }
                }


            }

        }
    }
}