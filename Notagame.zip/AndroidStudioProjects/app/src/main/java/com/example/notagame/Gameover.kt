package com.example.notagame

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.notagame.Excel.Companion.level
import com.example.notagame.Excel.Companion.score
import com.example.notagame.Excel.Companion.song1
import com.example.notagame.Excel.Companion.songGameOver
import kotlinx.android.synthetic.main.gameover.*
import kotlinx.android.synthetic.main.instructions.*

class Gameover : AppCompatActivity() {
    override fun onBackPressed() {
        startActivity(Intent(this, MainActivity::class.java))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.gameover)
        song1!!.stop()
        songGameOver!!.start()
        val hspreference = SavedData(this)
        val tspreference = SavedData(this)
        levelg.text = level.toString()
        scoreg.text = score.toString()
        highscoreg.text = hspreference.gethighscore().toString()
        tspreference.settotalscore(tspreference.gettotalscore() + score)
        back11.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
        }
        backhome.setOnClickListener {
            startActivity(Intent(this, Excel::class.java))
        }
    }
}