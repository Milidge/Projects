package com.example.notagame

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.instructions.*
import kotlinx.android.synthetic.main.selection.*

class Instructions :AppCompatActivity()  {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.instructions)
        back2.setOnClickListener{
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}