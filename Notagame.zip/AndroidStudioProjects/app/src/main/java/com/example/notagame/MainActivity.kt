package com.example.notagame

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import com.example.notagame.Excel.Companion.level
import com.example.notagame.Excel.Companion.maincount
import com.example.notagame.Excel.Companion.score
import kotlinx.android.synthetic.main.activity_main.*
import androidx.core.app.ComponentActivity
import androidx.core.app.ComponentActivity.ExtraData
import androidx.core.content.ContextCompat.getSystemService
import android.icu.lang.UCharacter.GraphemeClusterBreak.T





class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if(maincount == 0) {
            homescreen.setBackgroundResource(R.drawable.white)
            start.isEnabled = false
            settings.isEnabled = false
            credits.isEnabled = false
            instructions.isEnabled = false
            totalscoreh.alpha = 0f
            editText.alpha = 0f
            editText.isEnabled = false
            send.isEnabled = false
            Handler().postDelayed({
                cologo.setImageResource(R.drawable.transparent)
            }, 1500)
            Handler().postDelayed({
                homescreen.setBackgroundResource(R.drawable.home)
                start.isEnabled = true
                settings.isEnabled = true
                credits.isEnabled = true
                instructions.isEnabled = true
                editText.alpha = 1f
                totalscoreh.alpha = 1f
                editText.isEnabled = true
                send.isEnabled = true
            }, 2000)
            maincount = 1
        }else{
            cologo.setImageResource(R.drawable.transparent)
        }
        val tspreference = SavedData(this)
        totalscoreh.text = tspreference.gettotalscore().toString()
        score = 0
        level = 1

        send.setOnClickListener{
            val intent = Intent(Intent.ACTION_MAIN)
            intent.addCategory(Intent.CATEGORY_APP_MESSAGING)
            startActivity(intent)
        }
        //when start button pressed
        start.setOnClickListener {
            startActivity(Intent(this, Selection::class.java))
        }
        instructions.setOnClickListener{
            startActivity(Intent(this, Instructions::class.java))
        }
        //when settings button pressed
        settings.setOnClickListener {
            startActivity(Intent(this, Settings::class.java))
        }
        //when credits button pressed
        credits.setOnClickListener {
            startActivity(Intent(this, Credits::class.java))
        }

    }
}
