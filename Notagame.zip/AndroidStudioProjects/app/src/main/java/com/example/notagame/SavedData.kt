package com.example.notagame

import android.content.Context

class SavedData (context : Context) {

    val preference = context.getSharedPreferences("preference1", Context.MODE_PRIVATE)
    val preference2 = context.getSharedPreferences("preference2", Context.MODE_PRIVATE)
    fun gethighscore() : Int{
        return preference.getInt("highscore",0)
    }

    fun sethighscore(newhs: Int){
        val editor = preference.edit()
        editor.putInt("highscore",newhs)
        editor.apply()
    }

    fun gettotalscore() : Int{
        return preference2.getInt("totalscore",0)
    }

    fun settotalscore(newts: Int){
        val editor = preference2.edit()
        editor.putInt("totalscore",newts)
        editor.apply()
    }
}