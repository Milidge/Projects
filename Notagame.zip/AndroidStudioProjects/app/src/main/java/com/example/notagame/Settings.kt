package com.example.notagame

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.notagame.Excel.Companion.musicOn
import kotlinx.android.synthetic.main.instructions.*
import kotlinx.android.synthetic.main.settings.*

class Settings :AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.settings)
        musicToggle.isChecked = musicOn
        musicToggle.setOnClickListener{
            musicOn = !musicOn
        }
        back3.setOnClickListener{
            startActivity(Intent(this, MainActivity::class.java))
        }
    }
}