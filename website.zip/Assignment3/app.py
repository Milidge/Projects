from flask import Flask, render_template, request, url_for, redirect, session, flash, g
from functools import wraps
from sqlalchemy import text
from flask_sqlalchemy import SQLAlchemy
import sqlite3

app = Flask(__name__)
app.secret_key = "test"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///assignment3.db'

db = SQLAlchemy(app)


class Users(db.Model):  # establishes the model for users (login auth)

    __tablename__ = "users"

    stu = db.Column(db.Integer, primary_key=True, nullable=False)
    type = db.Column(db.String, nullable=False)
    username = db.Column(db.String, primary_key=True, nullable=False)
    password = db.Column(db.String, nullable=False)
    name = db.Column(db.String, nullable=False)


class Marks(db.Model): # establishes the model for marks (adding and changing marks for instructors, displaying for stu)
    __tablename__ = "marks"

    stu = db.Column(db.Integer, nullable=False, primary_key=True)
    username = db.Column(db.String, nullable=False, primary_key=True)
    aName = db.Column(db.String, nullable=False, primary_key=True)
    grade = db.Column(db.Float, nullable=True)


class Feedback(db.Model): # establishes the model for feedback
    __tablename__ = "feedback"

    username = db.Column(db.String, nullable=False, primary_key=True)
    info = db.Column(db.String, nullable=True, primary_key=True)


class Remarks(db.Model): # establishes the model for remarks (adding/deleting to the database)
    __tablename__ = "remark"

    stu = db.Column(db.Integer, nullable=False, primary_key=True)
    username = db.Column(db.String, nullable=False, primary_key=True)
    aName = db.Column(db.String, nullable=False, primary_key=True)
    info = db.Column(db.String, nullable=True)


def login_required(f): # wrap used for establishing what webpages must have a login (all of them, in this case)
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'username' in session: # if there is a user with a username in session, they may proceed, if not, login
            return f(*args, **kwargs)
        else:
            return redirect(url_for('login'))
    return wrap


@app.route('/', methods=['GET', 'POST'])
@login_required
def homepage():
    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        sql = text('SELECT * FROM users') # gets all user info
        results = db.engine.execute(sql) # gets all user info into an sqlalchemy object
        for result in results:
            if (request.form['username'] == result['username']) and (request.form['password'] == result['password']):
                # if the username and password are both in the db, then assign session a username value and continue
                session['username'] = request.form['username']
                msg_username = session['username'] # success messaging
                session['type'] = result['type']
                # assign a user type (instructor or student) used to control access to different parts of the file
                flash(f'Hello, {msg_username}! You have been logged in!')
                results.close() # ensure database is closed to further connections to avoid being locked out
                return redirect(url_for('homepage'))
        flash(f'Incorrect credentials. Try again!') # if error, then this message flashes and reloads
    return render_template('login.html', error=error)


@app.route('/adduser', methods=['GET', 'POST'])
def adduser():
    try:
        if request.method == 'POST': # when the form is completed, user is added to database using form fields
            user = Users(stu=request.form['stu'], type=request.form['type'], username=request.form['uname'],
                         password=request.form['spass'], name=request.form['sname'])
            db.session.add(user)
            db.session.commit()
            flash(f'Account Created! Log in now.')
            return redirect(url_for('login'))
        return render_template('adduser.html')
    except:
        flash(f'Account Creation Failed! Try again.')
        return redirect(url_for('login'))



@app.route('/logout')
@login_required
def logout():
    db.session.commit()
    session.pop('type', None)
    session.pop('username', None)
    flash(f'You have been logged out!')
    return redirect(url_for('login'))


@app.route('/calendar', methods=['GET', 'POST'])
@login_required
def calendar():
    if request.method == 'POST':
        return redirect(url_for('homepage'))
    return render_template('calendar.html')


@app.route('/news', methods=['GET', 'POST'])
@login_required
def news():
    if request.method == 'POST':
        return redirect(url_for('homepage'))
    return render_template('news.html')


@app.route('/lectures', methods=['GET', 'POST'])
@login_required
def lectures():
    if request.method == 'POST':
        return redirect(url_for('homepage'))
    return render_template('lectures.html')


@app.route('/labs', methods=['GET', 'POST'])
@login_required
def labs():
    if request.method == 'POST':
        return redirect(url_for('homepage'))
    return render_template('labs.html')


@app.route('/assignments', methods=['GET', 'POST'])
@login_required
def assignments():
    if request.method == 'POST':
        return redirect(url_for('homepage'))
    return render_template('assignments.html')


@app.route('/tests', methods=['GET', 'POST'])
@login_required
def tests():
    if request.method == 'POST':
        return redirect(url_for('homepage'))
    return render_template('tests.html')


@app.route('/resources', methods=['GET', 'POST'])
@login_required
def resources():
    if request.method == 'POST':
        return redirect(url_for('homepage'))
    return render_template('resources.html')


@app.route('/team', methods=['GET', 'POST'])
@login_required
def team():
    if request.method == 'POST':
        return redirect(url_for('homepage'))
    return render_template('courseteam.html')


@app.route('/feedback', methods=['GET', 'POST'])
@login_required
def feedback():
    if session['type'] == 'Student':
        if request.method == 'POST':
            feedback = Feedback(username=request.form['username'], info=request.form['info'])
            db.session.add(feedback)
            db.session.commit()
            flash(f'Feedback Submitted! Thank you!')
            return redirect(url_for('homepage'))
        return render_template('feedback.html')
    else:
        try:
            current_username = session['username']
            sql5 = text("""SELECT info FROM Feedback WHERE username = '{}'""".format(current_username))
            feedback = db.engine.execute(sql5)
            return render_template('feedback.html.', feedback=feedback)
        finally:
            feedback.close()
        if request.method == 'POST':
            return redirect(url_for('homepage'))
    return render_template('feedback.html')


@app.route('/marks', methods=['GET', 'POST'])
@login_required
def marks():
    current_username = session['username']
    if session['type'] != 'Student':
        try:
            sql0 = text("""SELECT * FROM Marks ORDER BY stu """)
            marks = db.engine.execute(sql0)
            return render_template('marks.html', marks=marks)
        finally:
            marks.close()
    else:
        try:
            sql1 = text("""SELECT * FROM Marks WHERE username = '{}'""".format(current_username))
            marks = db.engine.execute(sql1)
            if request.method == 'POST':
                return redirect(url_for('homepage'))
            return render_template('marks.html', marks=marks)
        finally:
            marks.close()


@app.route('/remarks', methods=['GET', 'POST'])
@login_required
def remarks():
    current_username = session['username']
    if session['type'] != 'Student':
        try:
            sql3 = text("""SELECT * FROM remark ORDER BY stu""")
            remarks_i = db.engine.execute(sql3)
            return render_template('remarks.html', remarks_i=remarks_i)
        finally:
            remarks_i.close()
    else:
        try:
            sql2 = text("""SELECT aName FROM Marks WHERE username = '{}'""".format(current_username))
            remarks = db.engine.execute(sql2)

            if request.method == 'POST':
                remark = Remarks(stu=request.form['stunum'], username=request.form['uname'],
                                 aName=request.form['aname'], info=request.form['info'])
                db.session.add(remark)
                remarks.close()
                db.session.commit()
                flash(f'Request sent.')
                return redirect(url_for('homepage'))
            return render_template('remarks.html', remarks=remarks)
        finally:
            remarks.close()


@app.route('/addmarks', methods=['GET', 'POST'])
@login_required
def addmarks():
    if session['type'] == 'Student':
        flash(f'Instructor access only!')
        return redirect(url_for('homepage'))

    if request.method == 'POST':
        mark = Marks(stu=request.form['stunum'], username=request.form['username'], aName=request.form['aname'],
                     grade=request.form['grade'])
        db.session.add(mark)
        db.session.commit()
        flash(f'Grade added!')
        return redirect(url_for('addmarks'))

    return render_template('addmarks.html')


@app.route('/changegrade', methods=['GET', 'POST'])
@login_required
def changegrade():
    if session['type'] == 'Student':
        return redirect(url_for('homepage'))

    sql3 = text("""SELECT * FROM remark ORDER BY stu""")
    remarks = db.engine.execute(sql3)

    if request.method == 'POST':
        remarks.close()
        str1 = str(request.form['requestlist'])
        data = str1.split('-')
        data[0] = int(data[0])
        new = Marks.query.filter_by(stu=data[0], username=data[1], aName=data[2]).first()
        new2 = Remarks.query.filter_by(stu=data[0], username=data[1], aName=data[2]).first()
        new.grade = request.form['grade']
        db.session.delete(new2)
        db.session.commit()
        flash(f'Grade Changed.')
        return redirect(url_for('homepage'))
    return render_template('changegrade.html', remarks=remarks)


if __name__ == '__main__':
    app.run(debug=True)
