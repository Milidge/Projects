from app import db
from app import Users
from app import Marks
from app import Remarks
from app import Feedback

db.drop_all()
db.create_all()


db.session.add(Users(stu=1, type="Student", username="student1", password="student1", name="student1"))
db.session.add(Users(stu=2, type="Instructor", username="instructor1", password="instructor1", name="instructor1"))
db.session.add(Users(stu=3, type="Instructor", username="instructor2", password="instructor2", name="instructor2"))
db.session.add(Users(stu=4, type="Student", username="student2", password="student2", name="student2"))

db.session.add(Marks(stu=1, username="student1", aName="Project 1", grade=92))
db.session.add(Marks(stu=1, username="student1", aName="Project 2", grade=50.2))
db.session.add(Marks(stu=1, username="student1", aName="Project 5", grade=100))
db.session.add(Marks(stu=4, username="student2", aName="Project 1", grade=50))
db.session.add(Marks(stu=4, username="student2", aName="Project 2", grade=99.9))
db.session.add(Marks(stu=4, username="student2", aName="Midterm", grade=0.1))

db.session.add(Remarks(stu=1, username='student1', aName='Project 1', info="I want a remark please!"))

db.session.add(Feedback(username='instructor1', info="You are a great instructor!"))

db.session.commit()
